import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-complaint-type-list',
  templateUrl: './complaint-type-list.component.html',
  styleUrl: './complaint-type-list.component.css'
})

export class ComplaintTypeListComponent {

}
